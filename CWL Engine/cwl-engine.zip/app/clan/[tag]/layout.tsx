import ClanHero from "@/app/components/ClanHero";
import ClanNavigation from "@/app/components/ClanNavigation";
import ScrollToTop from "@/app/components/ScrollToTop";
import { prisma } from "@/app/lib/prisma";
import { getCwlPromotionPosition } from "@/app/actions/cwlActions";

export default async function ClanLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ tag: string }>;
}) {
  const { tag } = await params;

  const res = await fetch(
    `http://localhost:3000/api/clan/${tag}`,
    {
      cache: "no-store",
    }
  );

  const clan = await res.json();

  if (clan.error) {
    return (
      <main className="min-h-screen bg-neutral-950 text-white flex items-center justify-center">
        <h1 className="text-2xl font-bold">
          Clan niet gevonden.
        </h1>
      </main>
    );
  }

  /*
   * Kijk of er momenteel een actieve CWL is.
   */
  let promotion = null;

  const normalizedTag = tag.startsWith("#")
    ? tag
    : `#${tag}`;

  const latestCwlMatchup =
    await prisma.cwlMatchup.findFirst({
      where: {
        OR: [
          {
            clanATag: normalizedTag,
          },
          {
            clanBTag: normalizedTag,
          },
          {
            clanATag:
              normalizedTag.replace("#", ""),
          },
          {
            clanBTag:
              normalizedTag.replace("#", ""),
          },
        ],
      },
      orderBy: {
        round: "desc",
      },
    });

  if (latestCwlMatchup?.season) {
    promotion =
      await getCwlPromotionPosition(
        latestCwlMatchup.season,
        normalizedTag,
        clan.warLeague?.name ?? ""
      );
  }

  return (
    <main className="min-h-screen bg-neutral-950 text-white">
      <ScrollToTop />

      <div className="relative mx-auto max-w-7xl p-8">
        <ClanHero
          clan={clan}
          promotion={promotion}
        />

        <ClanNavigation tag={tag} />

        {children}
      </div>
    </main>
  );
}