import type {
  CwlClanStats,
  CwlSimulationResult,
} from "./types";

import {
  buildClanPredictionStats,
} from "./stats";

import type {
  CwlFutureMatchup,
} from "./prediction";

/*
 * Aantal simulaties.
 */
const DEFAULT_SIMULATIONS = 20_000;

/*
 * ------------------------------------------------
 * HULPFUNCTIES
 * ------------------------------------------------
 */

function clamp(
  value: number,
  min: number,
  max: number
): number {
  return Math.min(
    max,
    Math.max(
      min,
      value
    )
  );
}

/*
 * Willekeurig getal volgens een normale verdeling.
 *
 * Hiermee kunnen we realistische variatie
 * simuleren rond een gemiddelde.
 */
function randomNormal(
  mean: number,
  standardDeviation: number
): number {
  if (
    standardDeviation <= 0
  ) {
    return mean;
  }

  let u = 0;
  let v = 0;

  while (u === 0) {
    u = Math.random();
  }

  while (v === 0) {
    v = Math.random();
  }

  const standardNormal =
    Math.sqrt(
      -2 *
        Math.log(u)
    ) *
    Math.cos(
      2 *
        Math.PI *
        v
    );

  return (
    mean +
    standardNormal *
      standardDeviation
  );
}

/*
 * Normaliseer clan-tags zodat
 * "#ABC" en "ABC" hetzelfde zijn.
 */
function normalizeTag(
  tag: string
): string {
  return tag
    .replace("#", "")
    .toUpperCase();
}

/*
 * ------------------------------------------------
 * CLAN STATISTIEKEN
 * ------------------------------------------------
 */

/*
 * Historisch gemiddelde aantal sterren.
 */
function getAverageStars(
  clan: CwlClanStats
): number {
  const completedWars =
    clan.warHistory.filter(
      (war) =>
        war.state ===
        "warEnded"
    );

  if (
    completedWars.length === 0
  ) {
    return clan.warSize === 30
      ? 75
      : 38;
  }

  const total =
    completedWars.reduce(
      (sum, war) =>
        sum + war.stars,
      0
    );

  return (
    total /
    completedWars.length
  );
}

/*
 * Historische standaardafwijking.
 *
 * Hiermee voorkomen we dat iedere simulatie
 * exact hetzelfde resultaat krijgt.
 */
function getStarsDeviation(
  clan: CwlClanStats
): number {
  const completedWars =
    clan.warHistory.filter(
      (war) =>
        war.state ===
        "warEnded"
    );

  if (
    completedWars.length < 2
  ) {
    return clan.warSize === 30
      ? 4
      : 2.5;
  }

  const average =
    getAverageStars(
      clan
    );

  const variance =
    completedWars.reduce(
      (sum, war) =>
        sum +
        Math.pow(
          war.stars -
            average,
          2
        ),
      0
    ) /
    completedWars.length;

  return Math.max(
    1,
    Math.sqrt(
      variance
    )
  );
}

/*
 * Historische gemiddelde destruction.
 */
function getAverageDestruction(
  clan: CwlClanStats
): number {
  const completedWars =
    clan.warHistory.filter(
      (war) =>
        war.state ===
        "warEnded"
    );

  if (
    completedWars.length === 0
  ) {
    return 85;
  }

  return (
    completedWars.reduce(
      (sum, war) =>
        sum + war.destruction,
      0
    ) /
    completedWars.length
  );
}

/*
 * Bepaal recente vorm.

 * Positief = recente wars beter.
 * Negatief = recente wars slechter.
 */
function getRecentForm(
  clan: CwlClanStats
): number {
  const completedWars =
    clan.warHistory.filter(
      (war) =>
        war.state ===
        "warEnded"
    );

  if (
    completedWars.length < 2
  ) {
    return 0;
  }

  const recentCount =
    Math.min(
      2,
      completedWars.length
    );

  const recent =
    completedWars.slice(
      -recentCount
    );

  const older =
    completedWars.slice(
      0,
      completedWars.length -
        recentCount
    );

  if (
    older.length === 0
  ) {
    return 0;
  }

  const recentAverage =
    recent.reduce(
      (sum, war) =>
        sum + war.stars,
      0
    ) /
    recent.length;

  const olderAverage =
    older.reduce(
      (sum, war) =>
        sum + war.stars,
      0
    ) /
    older.length;

  return (
    recentAverage -
    olderAverage
  );
}

/*
 * ------------------------------------------------
 * MATCHUP MODEL
 * ------------------------------------------------
 */

/*
 * Verwachte sterren tegen een specifieke
 * tegenstander.
 *
 * We beginnen met de eigen historische
 * prestatie en passen die voorzichtig aan
 * op basis van de prestaties van de tegenstander.
 */
function getExpectedStarsAgainstOpponent(
  clan: CwlClanStats,
  opponent: CwlClanStats
): number {
  const ownAverage =
    getAverageStars(
      clan
    );

  const opponentAverage =
    getAverageStars(
      opponent
    );

  const ownForm =
    getRecentForm(
      clan
    );

  const opponentForm =
    getRecentForm(
      opponent
    );

  /*
   * Baseline:
   * eigen historische prestatie.
   */
  let expected =
    ownAverage;

  /*
   * Sterkere tegenstanders maken het
   * doorgaans moeilijker om maximale
   * destruction/sterren te halen.
   *
   * We gebruiken hier bewust een beperkte
   * correctie zodat één uitschieter niet
   * het hele model omgooit.
   */
  const opponentStrength =
    opponentAverage /
    Math.max(
      1,
      clan.warSize === 30
        ? 75
        : 38
    );

  expected -=
    (opponentStrength -
      1) *
    4;

  /*
   * Recente vorm.
   */
  expected +=
    ownForm *
    0.35;

  /*
   * Een tegenstander die zelf extreem
   * goed/slecht in vorm is, geeft een
   * kleine extra correctie.
   */
  expected -=
    opponentForm *
    0.15;

  return clamp(
    expected,
    0,
    clan.warSize === 30
      ? 90
      : 45
  );
}

/*
 * Verwachte destruction tegen een
 * specifieke tegenstander.
 */
function getExpectedDestructionAgainstOpponent(
  clan: CwlClanStats,
  opponent: CwlClanStats
): number {
  const ownAverage =
    getAverageDestruction(
      clan
    );

  const opponentAverage =
    getAverageDestruction(
      opponent
    );

  /*
   * Als een tegenstander gemiddeld
   * zeer weinig destruction weggeeft,
   * verwachten we iets meer moeite.
   */
  const difficulty =
    (100 -
      opponentAverage) *
    0.05;

  return clamp(
    ownAverage -
      difficulty,
    0,
    100
  );
}

/*
 * ------------------------------------------------
 * GEBRUIK VAN AANVALLEN
 * ------------------------------------------------
 */

/*
 * Bepaal hoeveel invloed een lopende war
 * moet hebben.
 *
 * Als een clan bijvoorbeeld al 15/15
 * aanvallen heeft gebruikt, is er geen
 * toekomstig potentieel meer.
 */
function getCurrentWarRemainingFactor(
  clan: CwlClanStats
): number {
  const currentWar =
    clan.warHistory.find(
      (war) =>
        war.state ===
        "inWar"
    );

  if (!currentWar) {
    return 1;
  }

  if (
    currentWar.attacksAvailable <=
    0
  ) {
    return 1;
  }

  return clamp(
    currentWar.attacksRemaining /
      currentWar.attacksAvailable,
    0,
    1
  );
}

/*
 * Bereken hoeveel van de toekomstige
 * performance nog beschikbaar is.
 */
function getFuturePerformanceFactor(
  clan: CwlClanStats
): number {
  const currentFactor =
    getCurrentWarRemainingFactor(
      clan
    );

  /*
   * Dit is geen beperking op toekomstige
   * wars. Het is vooral bedoeld om een
   * lopende war niet opnieuw volledig te
   * simuleren als de aanvallen al grotendeels
   * gebruikt zijn.
   */
  return clamp(
    currentFactor,
    0,
    1
  );
}

/*
 * ------------------------------------------------
 * TOEKOMSTIGE WAR
 * ------------------------------------------------
 */

type SimulatedClan = {
  tag: string;
  name: string;

  warSize: 15 | 30;

  stars: number;
  bonusStars: number;
  destruction: number;

  totalStars: number;
};

/*
 * Maak een simulatieversie van een clan.
 */
function createSimulatedClan(
  clan: CwlClanStats
): SimulatedClan {
  return {
    tag:
      clan.tag,

    name:
      clan.name,

    warSize:
      clan.warSize,

    stars:
      clan.stars,

    bonusStars:
      clan.bonusStars,

    destruction:
      clan.destruction,

    totalStars:
      clan.totalStars,
  };
}

/*
 * Zoek een gesimuleerde clan.
 */
function findSimulatedClan(
  clans: SimulatedClan[],
  tag: string
): SimulatedClan | undefined {
  const normalized =
    normalizeTag(
      tag
    );

  return clans.find(
    (clan) =>
      normalizeTag(
        clan.tag
      ) === normalized
  );
}

/*
 * Simuleer één toekomstige war.
 */
function simulateMatchup(
  matchup: CwlFutureMatchup,
  simulatedClans: SimulatedClan[],
  realClans: CwlClanStats[]
): void {
  const clanA =
    findSimulatedClan(
      simulatedClans,
      matchup.clanATag
    );

  const clanB =
    findSimulatedClan(
      simulatedClans,
      matchup.clanBTag
    );

  const realClanA =
    realClans.find(
      (clan) =>
        normalizeTag(
          clan.tag
        ) ===
        normalizeTag(
          matchup.clanATag
        )
    );

  const realClanB =
    realClans.find(
      (clan) =>
        normalizeTag(
          clan.tag
        ) ===
        normalizeTag(
          matchup.clanBTag
        )
    );

  if (
    !clanA ||
    !clanB ||
    !realClanA ||
    !realClanB
  ) {
    return;
  }

  /*
   * Verwachte sterren tegen deze
   * specifieke tegenstander.
   */
  let expectedA =
    getExpectedStarsAgainstOpponent(
      realClanA,
      realClanB
    );

  let expectedB =
    getExpectedStarsAgainstOpponent(
      realClanB,
      realClanA
    );

  /*
   * Als een clan momenteel een lopende
   * war heeft, gebruiken we het resterende
   * potentieel als extra informatie.
   */
  const factorA =
    getFuturePerformanceFactor(
      realClanA
    );

  const factorB =
    getFuturePerformanceFactor(
      realClanB
    );

  /*
   * Een volledig ongebruikte toekomstige
   * war blijft op 100%.
   *
   * Een lopende war met weinig aanvallen
   * over krijgt minder gewicht.
   */
  if (
    realClanA.currentWars >
    0
  ) {
    expectedA *=
      0.75 +
      factorA * 0.25;
  }

  if (
    realClanB.currentWars >
    0
  ) {
    expectedB *=
      0.75 +
      factorB * 0.25;
  }

  const deviationA =
    getStarsDeviation(
      realClanA
    );

  const deviationB =
    getStarsDeviation(
      realClanB
    );

  /*
   * Trek een realistische uitkomst.
   */
  const starsA =
    Math.round(
      clamp(
        randomNormal(
          expectedA,
          deviationA
        ),
        0,
        matchup.warSize === 30
          ? 90
          : 45
      )
    );

  const starsB =
    Math.round(
      clamp(
        randomNormal(
          expectedB,
          deviationB
        ),
        0,
        matchup.warSize === 30
          ? 90
          : 45
      )
    );

  /*
   * Destruction is de officiële
   * tie-breaker wanneer sterren gelijk zijn.
   */
  const expectedDestructionA =
    getExpectedDestructionAgainstOpponent(
      realClanA,
      realClanB
    );

  const expectedDestructionB =
    getExpectedDestructionAgainstOpponent(
      realClanB,
      realClanA
    );

  const destructionA =
    clamp(
      randomNormal(
        expectedDestructionA,
        2.5
      ),
      0,
      100
    );

  const destructionB =
    clamp(
      randomNormal(
        expectedDestructionB,
        2.5
      ),
      0,
      100
    );

  /*
   * Verwerk de sterren.
   */
  clanA.stars +=
    starsA;

  clanB.stars +=
    starsB;

  /*
   * Verwerk destruction.
   */
  clanA.destruction +=
    destructionA;

  clanB.destruction +=
    destructionB;

  /*
   * Bepaal winnaar.
   */
  let winner:
    "A" |
    "B" |
    "draw";

  if (
    starsA >
    starsB
  ) {
    winner = "A";
  } else if (
    starsB >
    starsA
  ) {
    winner = "B";
  } else if (
    destructionA >
    destructionB
  ) {
    winner = "A";
  } else if (
    destructionB >
    destructionA
  ) {
    winner = "B";
  } else {
    winner = "draw";
  }

  /*
   * Winnaar krijgt 10 bonussterren.
   *
   * Bij een echte draw krijgt niemand bonus.
   */
  if (
    winner === "A"
  ) {
    clanA.bonusStars +=
      10;
  }

  if (
    winner === "B"
  ) {
    clanB.bonusStars +=
      10;
  }

  /*
   * Werk totale score direct bij.
   */
  clanA.totalStars =
    clanA.stars +
    clanA.bonusStars;

  clanB.totalStars =
    clanB.stars +
    clanB.bonusStars;
}

/*
 * ------------------------------------------------
 * EINDSCORE
 * ------------------------------------------------
 */

function sortFinalStand(
  clans: SimulatedClan[]
): SimulatedClan[] {
  return [
    ...clans,
  ].sort((a, b) => {
    /*
     * Eerst officiële totale CWL-score.
     */
    if (
      b.totalStars !==
      a.totalStars
    ) {
      return (
        b.totalStars -
        a.totalStars
      );
    }

    /*
     * Bij gelijke score:
     * destruction als tie-breaker.
     */
    return (
      b.destruction -
      a.destruction
    );
  });
}

/*
 * ------------------------------------------------
 * MAXIMAAL HAALBARE SCORE
 * ------------------------------------------------
 */

function getMaximumPossibleScore(
  clan: CwlClanStats
): number {
  const maxPerWar =
    clan.warSize === 30
      ? 100
      : 55;

  const currentScore =
    clan.totalStars;

  const futureWars =
    clan.currentWars +
    clan.remainingWars;

  return Math.min(
    7 * maxPerWar,
    currentScore +
      futureWars *
        maxPerWar
  );
}

/*
 * ------------------------------------------------
 * ÉÉN SIMULATIE
 * ------------------------------------------------
 */

function runSingleSimulation(
  clans: CwlClanStats[],
  futureMatchups: CwlFutureMatchup[],
  promotionSlots: number
): boolean {
  const simulatedClans =
    clans.map(
      createSimulatedClan
    );

  /*
   * Sorteer matchups op ronde.
   *
   * Daardoor speelt Phoenix de CWL
   * chronologisch af.
   */
  const sortedMatchups =
    [
      ...futureMatchups,
    ].sort(
      (a, b) =>
        a.round -
        b.round
    );

  /*
   * Simuleer iedere resterende war.
   */
  for (
    const matchup of
      sortedMatchups
  ) {
    simulateMatchup(
      matchup,
      simulatedClans,
      clans
    );
  }

  /*
   * Als er geen toekomstige matchups
   * beschikbaar zijn, gebruiken we alleen
   * de huidige stand.
   */
  const finalStand =
    sortFinalStand(
      simulatedClans
    );

  const targetIndex =
    finalStand.findIndex(
      (clan) =>
        normalizeTag(
          clan.tag
        ) ===
        normalizeTag(
          clans[0].tag
        )
    );

  /*
   * Deze functie wordt aangeroepen met
   * de doelclan als eerste element.
   */
  const finalPosition =
    targetIndex + 1;

  return (
    finalPosition >
      0 &&
    finalPosition <=
      promotionSlots
  );
}

/*
 * ------------------------------------------------
 * HOOFDFUNCTIE
 * ------------------------------------------------
 */

/*
 * Simuleer de promotiekans.
 *
 * De functie werkt volledig in memory.
 *
 * Database:
 *     ↓
 * CwlClanStats
 *     ↓
 * CwlFutureMatchup[]
 *     ↓
 * 20.000 simulaties
 *     ↓
 * promotiekans
 */
export function simulatePromotionChance(
  clans: CwlClanStats[],
  targetClanTag: string,
  promotionSlots: number,
  futureMatchups: CwlFutureMatchup[] = [],
  simulations =
    DEFAULT_SIMULATIONS
): CwlSimulationResult {
  if (
    clans.length === 0 ||
    promotionSlots <= 0
  ) {
    return {
      promotionChance: 0,

      maximumPromotionChance: 0,

      simulations: 0,

      promotions: 0,

      currentPosition: 0,

      promotionSlots,

      currentScore: 0,

      maximumPossibleScore: 0,
    };
  }

  /*
   * Zoek de doelclan.
   */
  const targetIndex =
    clans.findIndex(
      (clan) =>
        normalizeTag(
          clan.tag
        ) ===
        normalizeTag(
          targetClanTag
        )
    );

  if (
    targetIndex === -1
  ) {
    return {
      promotionChance: 0,

      maximumPromotionChance: 0,

      simulations: 0,

      promotions: 0,

      currentPosition: 0,

      promotionSlots,

      currentScore: 0,

      maximumPossibleScore: 0,
    };
  }

  /*
   * Maak de doelclan de eerste clan.
   *
   * Daardoor kan runSingleSimulation
   * altijd dezelfde referentie gebruiken.
   */
  const orderedClans = [
    clans[targetIndex],
    ...clans.filter(
      (_, index) =>
        index !==
        targetIndex
    ),
  ];

  /*
   * Huidige stand.
   */
  const currentStand =
    [
      ...clans,
    ].sort(
      (a, b) => {
        if (
          b.totalStars !==
          a.totalStars
        ) {
          return (
            b.totalStars -
            a.totalStars
          );
        }

        return (
          b.destruction -
          a.destruction
        );
      }
    );

  const currentPosition =
    currentStand.findIndex(
      (clan) =>
        normalizeTag(
          clan.tag
        ) ===
        normalizeTag(
          targetClanTag
        )
    ) + 1;

  /*
   * Maximale theoretische score
   * van de doelclan.
   */
  const targetClan =
    clans[targetIndex];

  const maximumPossibleScore =
    getMaximumPossibleScore(
      targetClan
    );

  /*
   * Aantal succesvolle simulaties.
   */
  let promotions = 0;

  /*
   * Voer de simulaties uit.
   */
  for (
    let i = 0;
    i < simulations;
    i++
  ) {
    const promoted =
      runSingleSimulation(
        orderedClans,
        futureMatchups,
        promotionSlots
      );

    if (
      promoted
    ) {
      promotions++;
    }
  }

  /*
   * Promotiekans.
   */
  const promotionChance =
    simulations > 0
      ? (
          promotions /
          simulations
        ) *
        100
      : 0;

  /*
   * ------------------------------------------------
   * MAXIMAAL HAALBARE PROMOTIEKANS
   * ------------------------------------------------
   *
   * Dit is geen voorspelling.
   *
   * We berekenen hier of promotie theoretisch
   * nog mogelijk is.
   *
   * Als onze maximale score niet hoger kan
   * komen dan de huidige score van voldoende
   * andere clans, kunnen we nooit promoveren.
   */
  const targetMaximum =
    maximumPossibleScore;

  const otherCurrentScores =
    clans
      .filter(
        (clan) =>
          normalizeTag(
            clan.tag
          ) !==
          normalizeTag(
            targetClanTag
          )
      )
      .map(
        (clan) =>
          clan.totalStars
      )
      .sort(
        (a, b) =>
          b - a
      );

  const competitorsAhead =
    otherCurrentScores.filter(
      (score) =>
        score >
        targetMaximum
    ).length;

  const maximumPromotionChance =
    competitorsAhead >=
    promotionSlots
      ? 0
      : 100;

  return {
    promotionChance:
      Number(
        clamp(
          promotionChance,
          0,
          100
        ).toFixed(1)
      ),

    maximumPromotionChance:
      Number(
        clamp(
          maximumPromotionChance,
          0,
          100
        ).toFixed(1)
      ),

    simulations,

    promotions,

    currentPosition,

    promotionSlots,

    currentScore:
      targetClan.totalStars,

    maximumPossibleScore,
  };
}