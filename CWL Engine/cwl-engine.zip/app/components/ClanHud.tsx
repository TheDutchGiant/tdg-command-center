type ClanHudProps = {
  clan: {
    tag: string;
    members: number;
    warWinStreak: number;
    warLeague: {
      name: string;
    };
    badgeUrls: {
      large: string;
    };
  };

  promotion?: {
    position: number;
    promotionPosition: number;
    maximumPromotionPosition: number;
    currentStars: number;
    bonusStars: number;
    totalStars: number;
    destruction: number;
    currentWars: number;
    remainingWars: number;
  } | null;
};

export default function ClanHud({
  clan,
  promotion,
}: ClanHudProps) {
  const isMainClan =
    clan.tag === "#2JLLPVGUU";

  return (
    <>
      <div className="flex items-center gap-2 text-lg font-semibold">
        👥 <span>{clan.members}/50</span>
      </div>

      <img
        src={clan.badgeUrls.large}
        alt="Clan Badge"
        className="h-12 w-12"
      />

      <div className="flex items-center gap-2 text-lg font-semibold">
        ⚔️ <span>{clan.warLeague.name}</span>
      </div>

      <div className="flex items-center gap-2 text-lg font-semibold">
        🔥 <span>{clan.warWinStreak}</span>
      </div>

      {isMainClan && (
        <div className="flex items-center gap-2 text-lg font-semibold">
          🇳🇱 <span>Top 200</span>
        </div>
      )}

      {promotion && (
        <div className="flex items-center gap-3 text-lg font-semibold">
          <span>
            🏆 #{promotion.position}
          </span>

          <span>
            ⭐ {promotion.totalStars}
          </span>

          <span>
            💥 {promotion.destruction.toFixed(1)}%
          </span>

          <span>
            📈 {promotion.promotionPosition}%
          </span>

          <span className="text-sm text-neutral-400">
            max {promotion.maximumPromotionPosition}%
          </span>
        </div>
      )}
    </>
  );
}