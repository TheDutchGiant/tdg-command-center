import type {
  CwlClanStats,
  CwlSimulationResult,
} from "./types";

import type {
  CwlFutureMatchup,
} from "./prediction";

const DEFAULT_SIMULATIONS = 20_000;

function normalizeTag(tag: string): string {
  return tag.replace("#", "").toUpperCase();
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function getCompletedWars(clan: CwlClanStats) {
  return clan.warHistory.filter((war) => war.state === "warEnded");
}

/*
 * V12 bewust simpel.
 *
 * De prediction gebruikt alleen de variabelen die de eindstand
 * daadwerkelijk kunnen veranderen:
 *
 * 1. huidige score
 * 2. resterende aanvallen
 * 3. historische sterren per aanval
 * 4. tegenstander (via diens eigen sterren per aanval)
 * 5. bonussterren voor de daadwerkelijke warwinnaar
 *
 * Destruction wordt alleen gebruikt als tie-break.
 * Geen recent-form-factor, geen normal distributions,
 * geen extra "strength" correcties.
 */
function getAverageStarsPerAttack(clan: CwlClanStats): number {
  const wars = getCompletedWars(clan);
  let stars = 0;
  let attacks = 0;

  for (const war of wars) {
    stars += war.stars;
    attacks += war.attacksUsed;
  }

  if (attacks <= 0) {
    return clan.warSize === 30 ? 2.5 : 2.5;
  }

  return clamp(stars / attacks, 0, 3);
}

function getAverageDestructionPerAttack(clan: CwlClanStats): number {
  const wars = getCompletedWars(clan);
  let destruction = 0;
  let attacks = 0;

  for (const war of wars) {
    destruction += war.destruction;
    attacks += war.attacksUsed;
  }

  if (attacks <= 0) return 0;

  return clamp(destruction / attacks, 0, 100);
}

/*
 * Trek één discrete aanval uit de historische gemiddelde score.
 *
 * We gebruiken alleen de gemiddelde sterren per aanval.
 * Bijvoorbeeld 2.4 => 60% kans op 2 sterren en 40% op 3.
 * Hierdoor blijft de verwachte waarde exact gelijk aan 2.4
 * zonder kunstmatige normale verdeling.
 */
function sampleAttackStars(average: number): number {
  const mean = clamp(average, 0, 3);
  const lower = Math.floor(mean);
  const upper = Math.min(3, lower + 1);
  const fraction = mean - lower;

  if (upper === lower) return lower;

  return Math.random() < fraction ? upper : lower;
}

type SimulatedClan = {
  tag: string;
  name: string;
  stars: number;
  bonusStars: number;
  totalStars: number;
  destruction: number;
};

function createSimulatedClan(clan: CwlClanStats): SimulatedClan {
  return {
    tag: clan.tag,
    name: clan.name,
    stars: clan.stars,
    bonusStars: clan.bonusStars,
    totalStars: clan.totalStars,
    destruction: clan.destruction,
  };
}

function findSimulatedClan(
  clans: SimulatedClan[],
  tag: string
): SimulatedClan | undefined {
  const normalized = normalizeTag(tag);
  return clans.find((clan) => normalizeTag(clan.tag) === normalized);
}

function findRealClan(
  clans: CwlClanStats[],
  tag: string
): CwlClanStats | undefined {
  const normalized = normalizeTag(tag);
  return clans.find((clan) => normalizeTag(clan.tag) === normalized);
}

function simulateMatchup(
  matchup: CwlFutureMatchup,
  simulated: SimulatedClan[],
  realClans: CwlClanStats[]
): void {
  const a = findSimulatedClan(simulated, matchup.clanATag);
  const b = findSimulatedClan(simulated, matchup.clanBTag);
  const realA = findRealClan(realClans, matchup.clanATag);
  const realB = findRealClan(realClans, matchup.clanBTag);

  if (!a || !b || !realA || !realB) return;

  const avgA = getAverageStarsPerAttack(realA);
  const avgB = getAverageStarsPerAttack(realB);

  const attacksA = Math.max(0, matchup.clanAAttacksRemaining);
  const attacksB = Math.max(0, matchup.clanBAttacksRemaining);

  let addedStarsA = 0;
  let addedStarsB = 0;

  /*
   * Voor een preparation-war zijn alle aanvallen nog over.
   * Voor een inWar-war worden alleen resterende aanvallen getrokken.
   */
  for (let i = 0; i < attacksA; i++) {
    addedStarsA += sampleAttackStars(avgA);
  }

  for (let i = 0; i < attacksB; i++) {
    addedStarsB += sampleAttackStars(avgB);
  }

  /*
   * Destruction is alleen relevant wanneer de sterren gelijk zijn.
   * Daarom gebruiken we een eenvoudige verwachting, zonder extra
   * random model: resterende aanvallen * historische destruction/attack.
   */
  const addedDestructionA =
    attacksA * getAverageDestructionPerAttack(realA);
  const addedDestructionB =
    attacksB * getAverageDestructionPerAttack(realB);

  a.stars += addedStarsA;
  b.stars += addedStarsB;

  a.destruction += addedDestructionA;
  b.destruction += addedDestructionB;

  const finalStarsA = a.stars;
  const finalStarsB = b.stars;

  let winner: "A" | "B" | "draw";

  if (finalStarsA > finalStarsB) {
    winner = "A";
  } else if (finalStarsB > finalStarsA) {
    winner = "B";
  } else if (a.destruction > b.destruction) {
    winner = "A";
  } else if (b.destruction > a.destruction) {
    winner = "B";
  } else {
    winner = "draw";
  }

  /*
   * Bonus hoort bij de daadwerkelijke winnaar van deze war.
   * Een draw krijgt geen bonus.
   */
  if (winner === "A") {
    a.bonusStars += 10;
  } else if (winner === "B") {
    b.bonusStars += 10;
  }

  a.totalStars = a.stars + a.bonusStars;
  b.totalStars = b.stars + b.bonusStars;
}

function sortFinalStand(clans: SimulatedClan[]): SimulatedClan[] {
  return [...clans].sort((a, b) => {
    if (b.totalStars !== a.totalStars) {
      return b.totalStars - a.totalStars;
    }
    return b.destruction - a.destruction;
  });
}

function getMaximumPossibleScore(
  clan: CwlClanStats,
  futureMatchups: CwlFutureMatchup[]
): number {
  let maximum = clan.totalStars;

  for (const matchup of futureMatchups) {
    const isA = normalizeTag(matchup.clanATag) === normalizeTag(clan.tag);
    const isB = normalizeTag(matchup.clanBTag) === normalizeTag(clan.tag);
    if (!isA && !isB) continue;

    const attacks = isA
      ? matchup.clanAAttacksRemaining
      : matchup.clanBAttacksRemaining;

    const currentStars = matchup.state === "inWar"
      ? (isA ? matchup.clanAStars : matchup.clanBStars)
      : 0;

    const maxStarsPerWar = matchup.warSize === 30 ? 90 : 45;
    const additional = Math.max(
      0,
      Math.min(maxStarsPerWar - currentStars, attacks * 3)
    );

    const opponentCurrent = matchup.state === "inWar"
      ? (isA ? matchup.clanBStars : matchup.clanAStars)
      : 0;

    const opponentAttacks = isA
      ? matchup.clanBAttacksRemaining
      : matchup.clanAAttacksRemaining;

    const opponentMax = Math.max(
      0,
      Math.min(maxStarsPerWar - opponentCurrent, opponentAttacks * 3)
    );

    const canStillWin =
      currentStars + additional >= opponentCurrent + opponentMax;

    maximum += additional + (canStillWin ? 10 : 0);
  }

  return maximum;
}

function canGuaranteePromotion(
  clans: CwlClanStats[],
  futureMatchups: CwlFutureMatchup[],
  targetTag: string,
  slots: number
): boolean {
  const target = findRealClan(clans, targetTag);
  if (!target) return false;

  const threats = clans.filter((clan) => {
    if (normalizeTag(clan.tag) === normalizeTag(targetTag)) return false;
    return getMaximumPossibleScore(clan, futureMatchups) > target.totalStars;
  });

  return threats.length < slots;
}

function runSingleSimulation(
  clans: CwlClanStats[],
  futureMatchups: CwlFutureMatchup[],
  targetTag: string,
  slots: number
): boolean {
  const simulated = clans.map(createSimulatedClan);

  for (const matchup of [...futureMatchups].sort((a, b) => a.round - b.round)) {
    simulateMatchup(matchup, simulated, clans);
  }

  const finalStand = sortFinalStand(simulated);
  const index = finalStand.findIndex(
    (clan) => normalizeTag(clan.tag) === normalizeTag(targetTag)
  );

  return index >= 0 && index + 1 <= slots;
}

export function simulatePromotionChance(
  clans: CwlClanStats[],
  targetClanTag: string,
  promotionSlots: number,
  futureMatchups: CwlFutureMatchup[] = [],
  simulations = DEFAULT_SIMULATIONS
): CwlSimulationResult {
  if (!clans.length || promotionSlots <= 0) {
    return {
      promotionChance: 0,
      maximumPromotionChance: 0,
      simulations: 0,
      promotions: 0,
      currentPosition: 0,
      promotionSlots,
      currentScore: 0,
      maximumPossibleScore: 0,
    };
  }

  const target = findRealClan(clans, targetClanTag);
  if (!target) {
    return {
      promotionChance: 0,
      maximumPromotionChance: 0,
      simulations: 0,
      promotions: 0,
      currentPosition: 0,
      promotionSlots,
      currentScore: 0,
      maximumPossibleScore: 0,
    };
  }

  const currentStand = sortFinalStand(
    clans.map(createSimulatedClan)
  );

  const currentPosition =
    currentStand.findIndex(
      (clan) => normalizeTag(clan.tag) === normalizeTag(targetClanTag)
    ) + 1;

  const guaranteed = canGuaranteePromotion(
    clans,
    futureMatchups,
    targetClanTag,
    promotionSlots
  );

  let promotions = 0;

  if (guaranteed) {
    promotions = simulations;
  } else {
    for (let i = 0; i < simulations; i++) {
      if (
        runSingleSimulation(
          clans,
          futureMatchups,
          targetClanTag,
          promotionSlots
        )
      ) {
        promotions++;
      }
    }
  }

  const maximumPossibleScore =
    getMaximumPossibleScore(target, futureMatchups);

  return {
    promotionChance: Number(
      clamp(
        simulations > 0 ? (promotions / simulations) * 100 : 0,
        0,
        100
      ).toFixed(1)
    ),
    maximumPromotionChance: guaranteed ? 100 : 100,
    simulations,
    promotions,
    currentPosition,
    promotionSlots,
    currentScore: target.totalStars,
    maximumPossibleScore,
  };
}
